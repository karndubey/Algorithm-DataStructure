#include<bits/bits/stdc++.h
using namespace std;

int cutRod(int a[],int n)
{

}

int main()
{
    int p[]={0,80,90,95,100};
    cout<<cutRod(p,sizeof(p)/sizeof(p[0]));
    return 0;
}
