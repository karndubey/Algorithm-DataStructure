#include<bits/stdc++.h>
using namespace std;

bool subsetSum(int a[],int n, int x,int offset)
{
    bool dp[n+1][x+1];
    memset(dp,0,sizeof(dp));
    for(int i=1;i<=n;i++)
    {
        dp[i][a[i-1]] = 1;
    }
    for(int i=1;i<=n;i++)
    {
        dp[1][i]  = (i == a[i-1] ? 1 : 0);
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=x;j++)
        {
            cout<<dp[i][j]<<" ";
        }
        cout<<endl;
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=x;j++)
        {
            //dp[i][j] = dp[i-1][j];
            if(dp[i][j])
            {
                cout<<dp[i-1][j-a[i-1]]<<endl;
            }
            if(j-a[i-1] >= 0)
            {
                dp[i][j] = dp[i-1][j] | dp[i-1][j-a[i-1]];
            }
            else
            {
                dp[i][j] = dp[i-1][j];
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=x;j++)
        {
            cout<<dp[i][j]<<" ";
        }
        cout<<endl;
    }
    //backtracking
    int i = n,j=x;
    while(dp[n][x] && i && j)
    {
        cout<<a[i-1]-offset<<" ";
        if(dp[i-1][j])
            i--;
        else
        {
            j = j - a[i-1];
            i--;
        }
    }
    cout<<endl;
    return dp[n][x];
}

int main()
{
    int x = 10;
    int a[] = {9,5,3,7,4,10};
    int n = (sizeof(a)/sizeof(a[0]));
    int offset = *min_element(a,a+n);
    offset = min(x,offset);
    if(offset <= 0)
    {
        offset = (abs(offset));
        offset++;
        for(int i=0;i<n;i++)
        {
            a[i] += offset;
        }
        x += offset;
    }
    cout<<"Is it possible that subset of array is equal to a number X? "<<subsetSum(a,n,x,offset);
    return 0;
}

