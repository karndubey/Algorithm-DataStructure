//Calculate height of a binary tree

#include<iostream>
using namespace std;

struct node{
	int data;
	node *left, *right;
};

//Create new node
node *NewNode(int data){
	node *root = new node;
	root->data = data;
	root->left = NULL;
	root->right = NULL;
	return root;
}

//Calculate height of binary tree
//height is same as max depth from root
//max depth is (maximum of left and right child) + 1
int getHeight(node *root) {
	if(root == NULL)
		return 0;

	else{
		int l = getHeight(root->left);
		int r = getHeight(root->right);

		if(l>r)
			return l+1;
		else
			return r+1;
	}
}

int main() {
	node *root = NewNode(1);
	root->left = NewNode(2);
	root->right = NewNode(3);
	root->left->left = NewNode(4);
	root->left->right = NewNode(5);
	root->right->left = NewNode(6);
	root->left->left->left = NewNode(7);

	cout<<"Height of tree is: "<<getHeight(root);

	return 0;
}
