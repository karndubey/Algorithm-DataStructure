//Algo to construct tree from inorder and preorder

#include<iostream>
using namespace std;

struct node {
	int data;
	node *left, *right;
};

//search the element from preorder array in the inorder array
int search(int in[], int start, int end, int data) {
	for(int i = start; i <= end; i++) {
		if(in[i] == data)
			return i;
	}
}

//Create new node in tree
node *newNode(int data) {
	node *root = new node;
	root->data = data;
	root->left = NULL;
	root->right=NULL;

	return root;
}
 
//Construct tree from inorder and preorder traversal of a tree
//in[] contains inorder traversal
//pre[] contains preorder traversal
//start and end initially 0 to n-1
node* buildTree(int in[], int pre[], int start, int end) {
	static int i = 0;
	if(start > end)
		return NULL;
	
	node *root = newNode(pre[i++]);

	if(start == end)
		return root;

	int index = search(in, start, end, root->data);

	root->left = buildTree(in, pre, start, index-1);
	root->right = buildTree(in, pre, index+1, end);

	return root;
}

//print inorder traversal of the tree
void inorderTraversal(node *root) {
	if(root == NULL	)
		return;
	inorderTraversal(root->left);
	cout<<root->data<<" ";
	inorderTraversal(root->right);
}


int main() {
	int in[] = {2,8,4,10,5,9,12};
	int pre[] = {10,8,2,4,9,5,12};

	int n = sizeof(in)/sizeof(in[0]);

	node *root = buildTree(in, pre, 0, n-1);

	cout<<"Inorder traversal of tree:\n";
	inorderTraversal(root);

	return 0;
}
