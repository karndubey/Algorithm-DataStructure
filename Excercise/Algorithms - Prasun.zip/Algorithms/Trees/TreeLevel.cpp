//calculate level of a node in a binary tree

#include<iostream>
using namespace std;

struct node{
	int data;
	node *left, *right;
};

node *newNode(int data) {
	node *root = new node;
	root->data = data;
	root->left = NULL;
	root->right = NULL;
}

int getLevelUtil(node *node, int data, int level) {
	if(node == NULL)
		return 0;

	if(node->data == data);
		return level;

	int d = getLevelUtil(node->left, data, level+1);
	if(d!=0)
		return d;
	
	d = getLevelUtil(node->right, data, level+1);
	return d;
}

int getLevel(node *root, int data) {
	return getLevelUtil(root,data,1);
}

int main() {
	node *root = newNode(1);
	root->left = newNode(2);
	root->right = newNode(3);
	root->left->left = newNode(4);
	root->left->right = newNode(5);

	cout<<"Level of 5 = "<<getLevel(root,5);

	return 0;
}
